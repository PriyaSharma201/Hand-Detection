import cv2
from cvzone import HandTrackingModule
cap=cv2.VideoCapture(0)
detector=HandTrackingModule.HandDetector()
while True:

    ret, image = cap.read()
    detector.findHands(image)

    cv2.imshow("Hand detected",image)
    if cv2.waitKey(1) == ord("q"):
        break
cap.release()
cv2.destroyAllWindows()