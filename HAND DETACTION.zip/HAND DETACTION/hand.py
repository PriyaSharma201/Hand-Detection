# import cv2
# import mediapipe as mp                                                            

# md_drawing = mp.solutions.drawing_utils
# mphands = mp.solutions.hands

# # Open camera capture
# vid = cv2.VideoCapture(0)
# hands = mphands.Hands()

# #capturing 
# while True:
#     ret, image = vid.read()
#     # Flip the image
#     image = cv2.flip(image, 1)
    
#     # Convert image to RGB 
#     image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    
#     results = hands.process(image)
    
#     if results.multi_hand_landmarks:
#         for hand_landmarks in results.multi_hand_landmarks:
#             md_drawing.draw_landmarks(image, hand_landmarks, mphands.HAND_CONNECTIONS)

#     # Display the image with landmarks
#     cv2.imshow("Hand Gesture", image)
    
#     # Exit loop 
#     if cv2.waitKey(1) & 0xFF == ord('q'):
#         break

# vid.release()
# cv2.destroyAllWindows()



